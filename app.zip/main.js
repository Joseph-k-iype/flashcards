// TODO(you): Modify the file in whatever ways necessary to implement
// the flashcard app behavior.
const app = new App();
